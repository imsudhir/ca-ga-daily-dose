<?php
/**
 * Disable updates for built-in plugins/addons (not currently in use).
 *
 * @package TotalTheme
 * @subpackage Updates
 * @version 5.1
 */

namespace TotalTheme\Updates;

defined( 'ABSPATH' ) || exit;

final class Disable_Auto_Updates {

	/**
	 * Our single Disable_Auto_Updates instance.
	 *
	 * @var Disable_Auto_Updates
	 */
	private static $instance;

	/**
	 * Disable instantiation.
	 */
	private function __construct() {
		// Private to disabled instantiation.
	}

	/**
	 * Disable the cloning of this class.
	 *
	 * @return void
	 */
	final public function __clone() {
		throw new Exception( 'You\'re doing things wrong.' );
	}

	/**
	 * Disable the wakeup of this class.
	 *
	 * @return void
	 */
	final public function __wakeup() {
		throw new Exception( 'You\'re doing things wrong.' );
	}

	/**
	 * Create or retrieve the instance of Disable_Auto_Updates.
	 *
	 * @return Disable_Auto_Updates
	 */
	public static function instance() {
		if ( is_null( static::$instance ) ) {
			static::$instance = new Disable_Auto_Updates;
			static::$instance->init_hooks();
		}

		return static::$instance;
	}

	/**
	 * Run action hooks.
	 */
	public function init_hooks() {
		add_filter( 'auto_update_plugin', array( $this, 'plugin_auto_updates' ), 10, 2 );
	}

	/**
	 * Filter plugin auto updates.
	 */
	public function plugin_auto_updates( $update, $item ) {

		/*if ( 'total-theme-core' == $item->slug ) {
			return false;
		}*/

		return $update;

	}

}