<?php
/**
 * Theme Builder.
 *
 * @package TotalTheme
 * @subpackage ThemeBuilder
 * @version 5.1
 */

namespace TotalTheme;

use TotalTheme\Theme_Builder\Render_Template as Render_Template;
use TotalTheme\Theme_Builder\Location_Template as Location_Template;

defined( 'ABSPATH' ) || exit;

final class Theme_Builder {

	/**
	 * Our single Theme_Builder instance.
	 *
	 * @var Theme_Builder
	 */
	private static $instance;

	/**
	 * Disable instantiation.
	 */
	private function __construct() {
		// Private to disable instantiation.
	}

	/**
	 * Disable the cloning of this class.
	 *
	 * @return void
	 */
	final public function __clone() {
		throw new Exception( 'You\'re doing things wrong.' );
	}

	/**
	 * Disable the wakeup of this class.
	 *
	 * @return void
	 */
	final public function __wakeup() {
		throw new Exception( 'You\'re doing things wrong.' );
	}

	/**
	 * Main Theme_Builder Instance.
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof Theme_Builder ) ) {
			self::$instance = new Theme_Builder;
		}

		return self::$instance;
	}

	/**
	 * Do location.
	 */
	public function do_location( $location ) {

		// Check for elementor templates first
		if ( function_exists( 'elementor_theme_do_location' ) ) {
			$elementor_doc = elementor_theme_do_location( $location );
			if ( $elementor_doc ) {
				return true;
			}
		}

		// Check for theme templates
		$location_template = new Location_Template( $location );

		if ( ! empty( $location_template->template ) ) {

			$render_template = new Render_Template( $location_template->template, $location );

			return $render_template->render();

		}

	}

}