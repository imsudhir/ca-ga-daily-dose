<?php
/**
 * Card: Icon Box 3.
 *
 * @package TotalTheme
 * @subpackage Cards
 * @version 5.1
 */

defined( 'ABSPATH' ) || exit;

$output = '';

$output .= '<div class="wpex-card-inner wpex-flex wpex-flex-col wpex-flex-grow wpex-bg-gray-100 wpex-text-gray-900 wpex-p-30 wpex-text-center">';

	// Icon
	$output .= $this->get_icon( array(
		'size'  => 'sm',
		'class' => 'wpex-text-accent wpex-mb-20',
	) );

	// Title
	$output .= $this->get_title( array(
		'class' => 'wpex-heading wpex-text-lg wpex-mb-15',
	) );

	// Excerpt
	$output .= $this->get_excerpt( array(
		'class' => 'wpex-mb-15',
	) );

	// More Link
	$output .= $this->get_more_link( array(
		'class'  => 'wpex-mt-auto wpex-font-semibold',
		'text'   => esc_html__( 'Learn more', 'total' ),
		'suffix' => ' &rarr;',
	) );

$output .= '</div>';

return $output;