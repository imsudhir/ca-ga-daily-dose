<?php
/**
 * Card: Image 1
 *
 * @package TotalTheme
 * @subpackage Cards
 * @version 5.0
 */

defined( 'ABSPATH' ) || exit;

$output = '';

$output .= $this->get_thumbnail();

return $output;