<?php
/**
 * Open the footer reveal container
 *
 * @package Total WordPress theme
 * @subpackage Partials
 * @version 5.0
 */

defined( 'ABSPATH' ) || exit;

?>

<div class="footer-reveal-visible wpex-clr">