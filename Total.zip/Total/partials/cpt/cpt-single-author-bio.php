<?php
/**
 * CPT single author bio
 *
 * @package Total WordPress theme
 * @subpackage Partials
 * @version 5.0
 */

defined( 'ABSPATH' ) || exit;

wpex_get_template_part( 'author_bio' );