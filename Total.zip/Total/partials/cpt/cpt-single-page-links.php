<?php
/**
 * CPT single page links
 *
 * @package Total WordPress theme
 * @subpackage Partials
 * @version 5.0
 */

defined( 'ABSPATH' ) || exit;

wpex_get_template_part( 'link_pages' );