<?php
/**
 * CPT single thumbnail
 *
 * @package TotalTheme
 * @subpackage Partials
 * @version 5.0
 */

defined( 'ABSPATH' ) || exit;

wpex_cpt_single_thumbnail();