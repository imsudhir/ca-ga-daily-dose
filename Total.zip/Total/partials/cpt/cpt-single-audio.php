<?php
/**
 * CPT single audio
 *
 * @package TotalTheme
 * @subpackage Partials
 * @version 5.0
 */

defined( 'ABSPATH' ) || exit;

wpex_post_audio_html( $audio );