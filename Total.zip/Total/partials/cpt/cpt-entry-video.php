<?php
/**
 * CTP entry video
 *
 * @package TotalTheme
 * @subpackage Partials
 * @version 5.0
 *
 */

defined( 'ABSPATH' ) || exit;

?>

<div class="cpt-entry-video entry-video"><?php wpex_post_video_html(); ?></div>