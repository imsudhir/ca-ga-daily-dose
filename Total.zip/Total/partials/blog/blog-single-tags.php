<?php
/**
 * Single blog tags
 *
 * @package Total WordPress theme
 * @subpackage Partials
 * @version 5.0
 *
 */

defined( 'ABSPATH' ) || exit;

the_tags( '<div class="post-tags wpex-mb-40 wpex-last-mr-0">', '', '</div>' );