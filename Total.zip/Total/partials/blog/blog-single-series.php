<?php
/**
 * Single related posts
 *
 * This template part has been deprecated since Total 4.0
 *
 * @package Total WordPress theme
 * @subpackage Partials
 * @version 5.0
 */

defined( 'ABSPATH' ) || exit;

wpex_get_template_part( 'post_series' );