<?php
/**
 * Loop Top : Portfolio
 *
 * @package Total WordPress theme
 * @subpackage Partials
 * @version 5.0
 */

defined( 'ABSPATH' ) || exit;

?>

<div id="portfolio-entries" <?php wpex_portfolio_loop_top_class(); ?>>