<?php
/**
 * Loop Top : Custom Post Type & Pages entries
 *
 * @package Total WordPress theme
 * @subpackage Partials
 * @version 3.6.0
 */

defined( 'ABSPATH' ) || exit;

?>

<div <?php wpex_loop_top_class(); ?>>