<?php
/**
 * Loop Top : Staff
 *
 * @package Total WordPress theme
 * @subpackage Partials
 * @version 5.0
 */

defined( 'ABSPATH' ) || exit;

?>

<div id="staff-entries" <?php wpex_staff_loop_top_class(); ?>>