<?php
/**
 * Loop Top : Search Results
 *
 * @package Total WordPress theme
 * @subpackage Partials
 * @version 5.0
 */

defined( 'ABSPATH' ) || exit;

?>

<div id="search-entries" <?php wpex_search_loop_top_class(); ?>>