<?php
/**
 * Loop Top : Portfolio
 *
 * @package Total WordPress theme
 * @subpackage Partials
 * @version 5.0
 */

defined( 'ABSPATH' ) || exit;

?>

<div id="testimonials-entries" <?php wpex_testimonials_loop_top_class(); ?>>