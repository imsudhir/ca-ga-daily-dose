<?php
/**
 * Loop Top : Blog / Standard entries
 *
 * @package Total WordPress theme
 * @subpackage Partials
 * @version 5.0
 */

defined( 'ABSPATH' ) || exit;

?>

<div id="blog-entries" class="<?php wpex_blog_wrap_classes(); ?>">