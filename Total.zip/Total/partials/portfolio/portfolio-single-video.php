<?php
/**
 * Portfolio single video
 *
 * @package TotalTheme
 * @subpackage Partials
 * @version 5.0
 */

defined( 'ABSPATH' ) || exit;

wpex_portfolio_post_video();