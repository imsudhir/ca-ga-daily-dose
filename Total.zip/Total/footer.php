<?php
/**
 * The template for displaying the footer.
 *
 * @package TotalTheme
 * @subpackage Templates
 * @version 5.0
 */

defined( 'ABSPATH' ) || exit;

?>

			<?php wpex_hook_main_bottom(); ?>

		</main>

		<?php wpex_hook_main_after(); ?>

		<?php wpex_hook_wrap_bottom(); ?>

	</div>

	<?php wpex_hook_wrap_after(); ?>

</div>

<?php wpex_outer_wrap_after(); ?>

<?php wp_footer(); ?>

</body>
</html>