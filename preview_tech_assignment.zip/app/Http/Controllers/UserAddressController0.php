<?php

namespace App\Http\Controller;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Useraddress;
use App\Models\Statemaster;
use App\Models\Districtmaster;

class UserAddressController extends Controller
{
    //
    public function user(){
    // $user= Districtmaster::all();
    // $users = Useraddress::with('districtmaster')->get();

    $user_info = Useraddress::All();
    $user_info['user']=$user_info;
    $user_info['states']=Statemaster::All();
    $user_info['district']=Districtmaster::All();
    return $user_info;
    // $user= Statemaster::all();
    return view('user.pages.user', compact('user_info'));

    // return $users;
    }
}
