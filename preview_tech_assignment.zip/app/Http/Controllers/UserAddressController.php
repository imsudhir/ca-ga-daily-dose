<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Useraddress;
use App\Models\Statemaster;
use App\Models\Districtmaster;

class UserAddressController extends Controller
{
    //
    
    public function user(){
        // $user_info = Useraddress::All();
        $user_info['user'] = Useraddress::with('statemaster')->get();

        // $user_info['user']=Useraddress::All();
        $user_info['states']=Statemaster::All();
        $user_info['district']=Districtmaster::All();
        // $user_id='';
        // $user_info['district']=array();
        // foreach ($user_info['user'] as  $users) {
        // $district=Districtmaster::where(['statemaster_id'=>$users->districtmaster->statemaster_id])->get();
        // array_push($user_info['district'],$district);


        // }
        // return $user_info['district'];
        // return $user_info;
        // return $user_info;
        // $user= Statemaster::all();
// return $user_info;

        return view('user.pages.user', $user_info);
    }

    function getdistrict(Request $request){
        $state_id= $request->state_id;
        $district=Districtmaster::where('statemaster_id', $state_id)->get();
        $html='<option value="">select city</option>';
       
          foreach ($district as $list){
            $html.='<option value="'.$list->id.'">'.$list->DistrictName.'</option>';
          }
          echo $html;
     }
}
