@extends('user.layouts.app')

@section('content')
<h2>USER DATA</h2>
<table class="table table-hover">
 <thead> 
   <tr>
     <th>Sr. no</th>
     <th>User Name</th>
     <th>State</th>
     <th>District</th>
   </tr>
 </thead>
 <form role="form" id="userListForm" action="" method="POST"
  enctype="multipart/form-data">
  @csrf
  @method('PUT')
<tbody>
  <?php $sr_no=1; ?>
  @foreach ($user as $user_list)
  <tr>
    <td>{{$sr_no++}}</td>
    <td>{{$user_list->UserName}}</td>
    <td>
    <select class="form-control" name="state"   onchange="district_filter_handler(this,{{$sr_no}})">
    <option>select state</option>
    @foreach ($states as $states_list)
     <option value="{{$states_list->id}}" {{$user_list->districtmaster->statemaster_id == $states_list->id ? 'selected':''}}>{{$states_list->StateName}}</option>
    @endforeach
    </select>
  </td> 
    <td>
      <select class="form-control" id="district_list{{$sr_no}}">
        <option>select district</option>
        @foreach ($district as $district_list)
        {{-- {{$district_list}} --}}
        {{-- {{$user_list->districtmaster->id}} --}}
         <option value="{{$district_list->id}}" {{$user_list->districtmaster->id == $district_list->id ? 'selected':''}} >{{$district_list->DistrictName}}</option>
        {{-- <option value="{{$user_list->districtmaster->id}}" selected>{{$user_list->districtmaster->DistrictName}}</option> --}}
       @endforeach
        </select>
    </td>
  </tr>
  @endforeach



  
  
  </tbody>
   <input type="submit" value="update">

 </form>
</table>
</div>
 
@endsection
@section('script')
@endsection