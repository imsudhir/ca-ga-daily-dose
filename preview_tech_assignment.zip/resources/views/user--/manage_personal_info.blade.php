@extends('user/layout')
@section('page_title','User | Update Contact info')
@section('update_personal_info_selected','active')

@section('container')
 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        {{-- <div class="row mb-2">
          <div class="col-sm-6">
            <h1>DataTables</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">DataTables</li>
            </ol>
          </div>
        </div> --}}
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
          <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title"><b>MANAGE CONTACT INFORMATION.</b></h3>
               <a href="{{url('user/personal-info')}}" class="btn-sm btn-primary" style="float: right; position: absolute;right: 14px;margin: 0 auto;top: 8px;">  <i class="fa fa-arrow-left"  aria-hidden="true"></i></a>

              </div>
              <!-- /.card-header -->
              <form action="{{ route('user.manage_personal_info_process') }}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="card-body">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="form-group">
                          <label for="name">Name*</label>
                          <input type="text" name="name" disabled class="form-control" id="name" value="{{$update_personal_info[0]->name}}"
                           placeholder="name" />
                           
                        </div>
                    </div>
                    <div class="col-xl-4">
                        <div class="form-group">
                        <label for="p_address">Mobile number*</label>
                        <input type="text" name="phone" class="form-control" id="p_cphoneity" value="{{$update_personal_info[0]->phone}}"  placeholder="mobile number">
                        @error('phone')
                        <span class="text-danger" role="alert">
                            {{ $message }}
                        </span>
                    @enderror
                        </div>
                    </div>
                   
                    <div class="col-xl-4">
                      <div class="form-group">
                        <label for="city">State*</label>
                        <select class="form-control">
                          <option>option 1</option>
                          <option>option 2</option>
                          <option>option 3</option>
                          <option>option 4</option>
                          <option>option 5</option>
                        </select>
                        {{-- <input type="text" name="city" class="form-control" id="city" value="{{$update_personal_info[0]->city}}" placeholder="City"> --}}
                        @error('city')
                        <span class="text-danger" role="alert">
                            {{ $message }}
                        </span>
                    @enderror
                      </div>
                    </div>
                    <div class="col-xl-4">
                      <div class="form-group">
                        <label for="city">City*</label>
                        <input type="text" name="city" class="form-control" id="city" value="{{$update_personal_info[0]->city}}" placeholder="City">
                        @error('city')
                        <span class="text-danger" role="alert">
                            {{ $message }}
                        </span>
                    @enderror
                      </div>
                    </div>
                    
                </div>
                     
                    <div class="col-xl-4">
                        <div class="form-group">
                          <input type="hidden" name="update_user_id" value="{{session('USER_ID')}}">
                            <button class="btn btn-primary" type="submit" >SAVE</button>
                       
                        </div>
              </div>
            </form>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
@endsection
