
<?php $__env->startSection('page_title','User | Dashboard'); ?>
<?php $__env->startSection('container'); ?>
 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    

    <!-- Main content -->
    <section class="content mt-4">
      <div class="container-fluid">
          <div class="row">
          <div class="col-12">
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title"><b>Dashboard</b></h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <div class="row">
                    
                   
                  </div>
            
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev-work\my-git\cmw_assignment\resources\views/user/dashboard.blade.php ENDPATH**/ ?>