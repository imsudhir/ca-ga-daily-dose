
<script></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('/js/custom_user.js')); ?>"></script>
<?php /**PATH C:\dev-work\my-git\preview_tech_assignment\resources\views/user/layouts/footer.blade.php ENDPATH**/ ?>