<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
 
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo $__env->yieldContent('page_title'); ?></title>
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo e(asset('front_assets/css/all.min.css')); ?>">
   
 <link href="<?php echo e(asset('admin_asset/css/toastr.min.css')); ?>" rel="stylesheet">
  <!-- Theme style -->
  <link href="<?php echo e(asset('admin_asset/css/font-awesome.min.css')); ?>" rel="stylesheet">
   <link href="<?php echo e(asset('admin_asset/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('admin_asset/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('front_assets/css/adminlte.min.css')); ?>">
 

</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fa fa-bars"></i></a>
      </li>
       
       
    </ul>

    <!-- SEARCH FORM -->
 

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->
      
      <!-- Notifications Dropdown Menu -->
      
      <li class="nav-item">
        <a class="nav-link" data-toggle="dropdown" href="#">
          <i class="fa fa-user"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-sm dropdown-menu-right" style="margin-right: 13px !important;">
          <a href="#" class="dropdown-item">
            <?php echo e(session('USER_NAME')); ?>

          </a>
          <div class="dropdown-divider"></div>
          <a href="<?php echo e(url('user/logout')); ?>" class="dropdown-item dropdown-footer">Logout</a>
        </div>
      </li>
       
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel-1 mt-3 pb-3 mb-3 d-flex">
        <a  href="<?php echo e(url('user/dashboard')); ?>" class="image">
            <img style="height:auto; max-width:40%;" class="text-center" src="https://www.compendiousmedworks.com/assets/img/logo/cmw-logo.png" alt="">
        </a>
        <div class="info">
          <a href="#" class="d-block"></a>
        </div>
      </div>

      <!-- SidebarSearch Form -->
   

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item menu-open mb-2">
            <a href="<?php echo e(url('user/dashboard')); ?>" class="nav-link">
              <i class="fa fa-dashboard"></i> &nbsp;&nbsp;
              <p>
                Dashboard
              </p>
            </a>
            
          </li>
          <li class="nav-item menu-open mb-2">
             
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('user/personal-info')); ?>"  class="<?php echo $__env->yieldContent('userlist_selected'); ?> nav-link">
                  <i class="nav-icon fa fa-user"></i>
                  <p>
                    My contact details
                  </p>
                </a>
              </li>
             
            </ul>
          </li>
      
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  

    <?php $__env->startSection('container'); ?>

    <?php echo $__env->yieldSection(); ?>

    <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
      Anything you want
    </div>
    <!-- Default to the left -->
   </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->

<!-- Bootstrap 4 -->


<script src="<?php echo e(asset('admin_asset/js/jquery.min.js')); ?>"></script> 
<script src="<?php echo e(asset('admin_asset/js/responsive.bootstrap4.min.js')); ?>"></script>
 <script src="<?php echo e(asset('admin_asset/js/buttons.bootstrap4.min.js')); ?>"></script> 
<script src="<?php echo e(asset('admin_asset/js/vfs_fonts.js')); ?>"></script> 
<script src="<?php echo e(asset('admin_asset/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_asset/js/main.js')); ?>"></script>

<script src="<?php echo e(asset('admin_assets/js/adminlte.min.js')); ?>"></script>
<!-- adminLTE App -->
 
</body>
</html>
<?php /**PATH C:\dev-work\my-git\cmw_assignment\resources\views/user/layout.blade.php ENDPATH**/ ?>