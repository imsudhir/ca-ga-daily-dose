 
    <?php echo $__env->make('user.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper container">
 
  <?php echo $__env->yieldContent('content'); ?>

  <!-- /.content-wrapper -->
  <?php echo $__env->make('user.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->yieldContent('script'); ?>
</body>
</html>

<?php /**PATH C:\dev-work\my-git\preview_tech_assignment\resources\views/user/layouts/app.blade.php ENDPATH**/ ?>