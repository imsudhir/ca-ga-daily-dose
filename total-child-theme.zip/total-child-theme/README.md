Total Child Theme
=================

Child Theme for the Total WordPress theme.

### Usage
Simply download the zip and upload the zip (total-child-theme-master.zip) under your WordPress dashboard at Appearance > Themes. Or extract and uplod via FTP at wp-content/themes/.


### Renaming
You can of course rename the zip file so it isn't called total-child-theme-master.zip (you should do this so it makes more sense) and also change the "Theme Name" at the top of the style.css file.
